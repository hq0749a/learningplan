import pygame
import time, random
from apscheduler.schedulers.blocking import BlockingScheduler
from apscheduler.schedulers.background import BackgroundScheduler
from pygame.locals import *


screen = pygame.display.set_mode((512, 568), 0, 0)
class Base_Job():
    # def __init__(self):
    #     scheduler = BlockingScheduler()
    #     scheduler.add_job(self.job, 'interval', seconds=0.3, id='job')
    #
    #     scheduler.start()
    def __init__(self):
        while True:
            self.job()
            time.sleep(0.03)



    def job(self):
        self.update()
        self.draw()

    def update(self):
        pass

    def draw(self):
        pass



class Base_Obj():

    def init_update(self):
        pass

    def init_draw(self):
        pass





def Director():
    def __init__(self):
        pass



class Layer(Base_Obj):
    global screen
    def __init__(self):
        self.m = -968
        # 生成windows窗口，pygame.display.set_mode(resolution=(0,0),flags=0,depth=0)
        # 返回的也是一个surface对象，resolution可以控制生成windows窗口的大小
        self.bg = pygame.image.load("./images/bg2.jpg")
        # print(self.bg)
        super().__init__()


    def init_draw(self):
        screen.blit(self.bg, (0,self.m))  # 每次绘图覆盖  切割图片，rect left top ，w，h
        self.m += 2
        if self.m >= -200:
            self.m = -968





class Hero_Plane(Base_Obj):
    global screen
    def __init__(self):
        self.x = 200
        self.y = 400
        self.image = pygame.image.load("./images/me.png")
        self.ammo_list = []
        super().__init__()


    def init_update(self):
        pass


    def init_draw(self):


        screen.blit(self.image, (self.x, self.y))  # 每次绘图覆盖  切割图片，rect left top ，w，h
        for a in self.ammo_list:
            a.init_draw()
            if a.move():
                self.ammo_list.remove(a)




    def move_l(self):
        self.x -= 5
        if self.x <= 0:
            self.x = 0

    def move_r(self):
        self.x += 5
        if self.x >= 406:
            self.x = 406

    def move_u(self):
        self.y -= 5
        if self.y <= 0:
            self.y = 0

    def move_d(self):
        self.y += 5
        if self.y >= 492:
            self.y = 492

    def shoot(self):
        self.ammo_list.append(Hero_Bullet( self.x + 50, self.y))
        self.ammo_list.append(Hero_Bullet(self.x + 56, self.y))
        pass

    def dead(self):
        self.d -= 1

    # # 监听键盘控制按键
    def get_key(self):
        for e in pygame.event.get():
            if e.type == QUIT:
                print("exit")
                exit()
        pressed_keys = pygame.key.get_pressed()
        if pressed_keys[K_LEFT] or pressed_keys[K_a]:
            self.move_l()
        elif pressed_keys[K_RIGHT] or pressed_keys[K_d]:
            self.move_r()

        if pressed_keys[K_UP] or pressed_keys[K_w]:
            self.move_u()
        elif pressed_keys[K_DOWN] or pressed_keys[K_s]:
            self.move_d()
        if pressed_keys[K_SPACE]:
            self.shoot()

class Hero_Bullet(Base_Obj):
    global screen
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.image = pygame.image.load("./images/pd.png")



    def init_update(self):
        pass

    def init_draw(self):
        print(self.y)
        screen.blit(self.image, (self.x, self.y))

    def move(self):
        self.y -= 10
        if self.y <= -20:
            return True

class Scene(Base_Job):

    global screen
    def __init__(self):

        self.Hero_Plane= Hero_Plane()
        self.Layer = Layer()
        super().__init__()

    def update(self):
        self.Hero_Plane.get_key()


    def draw(self):
        self.Layer.init_draw()
        self.Hero_Plane.init_draw()
        self.Hero_Plane.init_update()



        pygame.display.update()





if __name__ == "__main__":

    # Director
    obj = Scene()



