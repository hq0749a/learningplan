
import time
import pygame

screen = pygame.display.set_mode((512, 568), 0, 0)


class Base_Job():
    def __init__(self):
        while True:
            self.update()
            self.draw()
            time.sleep(0.03)

    def update(self):
        pass
    def draw(self):
        pass

class Base_obj():
    def __init__(self):
        pass

    def init_update(self):
        pass
    def init_draw(self):
        pass



class Director():
    pass

class Scene(Base_Job):
    def __init__(self):
        self.Layer = Layer()
        super().__init__()

    def update(self):
        pass
    def draw(self):
        self.Layer.init_draw()
        pygame.display.update()

class Layer(Base_obj):
    global screen
    def __init__(self):
        self.m = -968
        self.bg = pygame.image.load("./images/bg2.jpg")
        super().__init__()

    def init_update(self):
        pass
    def init_draw(self):
        # print('bb')
        screen.blit(self.bg, (0, self.m))  # 每次绘图覆盖  切割图片，rect left top ，w，h
        self.m += 2
        if self.m >= -200:
            self.m = -968







class Hero_Plane():
    pass

class Hero_Bullet():
    pass












if __name__ == '__main__':
    obj = Scene()