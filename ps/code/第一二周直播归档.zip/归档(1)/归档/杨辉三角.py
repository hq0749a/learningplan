# -*- coding: utf-8 -*-
# @File  : 作业.py
# @Author: yh
# @Date  : 2019/8/14
# @Software: PyCharm


#  作业
#           1
#          / \
#         1   1
#        / \ / \
#       1   2   1
#      / \ / \ / \
#     1   3   3   1
#    / \ / \ / \ / \
#   1   4   6   4   1
#  / \ / \ / \ / \ / \
# 1   5   10  10  5   1
# 把每一行看做一个list，试写一个generator，不断输出下一行的list：


# 输出:
# [1]
# [1, 1]        [0, 1, 2, 1 ]
# [1, 2, 1]     [ 1, 2, 1,0 ]    [1,3,3,1]
# [1, 3, 3, 1]
# [1, 4, 6, 4, 1]

# 1, 1
# [0, 1, 1]
# [1, 1, 0]
# [1, 2, 1]
#
# # [1, 2, 1]
# [0, 1, 2, 1]
# [1, 2, 1, 0]




def triangles():
    rowNumber = 5
    l = [1]
    yield l
    every_line = [l]
    for i in range(1, rowNumber):
        row = list(map(lambda x, y: x + y, [0] + every_line[-1],  every_line[-1] + [0]))
        every_line.append(row)


        yield row

n = 0
results = []
for t in triangles():
    print(t)
    results.append(t)
    n = n + 1
    if n == 10:
        break
if results == [
    [1],
    [1, 1],
    [1, 2, 1],
    [1, 3, 3, 1],
    [1, 4, 6, 4, 1],
]:
    print('测试通过!')
else:
    print('测试失败!')

# def generate(numRows):
#     """
#     :type numRows: int
#     :rtype: List[List[int]]
#     """
#     if numRows == 0:
#         return []
#     l1 = [[1]]
#     n = 1
#     while n < numRows:
#         l1.append(list(map(lambda x, y: x + y, [0] + l1[-1], l1[-1] + [0])))
#         n += 1
#     return l1
#
#
#
# print(generate(5))