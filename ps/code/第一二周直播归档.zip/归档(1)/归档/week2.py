"""
@Author: B.N
@Date: 2019-08-02 16:09:42
@LastEditors: B.N
@LastEditTime: 2019-08-02 18:46:36
@Description: python特训班第一周作业:银行自动提款机
"""
from DB import DB
import getpass
# 创建一个list变量User_Information，储存着用户信息
User_Information = [{"User_Name": "ZhangSan", "Password" : "111111", "balance" : 123165.15, "Account_State" : True , "Error_Count" : 0},
                   {"User_Name": "LiSi", "Password": "222222", "balance": 16561.45 , "Account_State" : True , "Error_Count" : 0},
                   {"User_Name": "WangWu", "Password": "333333", "balance" : 489849.54, "Account_State" : True , "Error_Count" : 0},
                   {"User_Name": "ZhaoLiu", "Password": "444444", "balance" : 965561.15, "Account_State" : False, "Error_Count" : 3}]


User_Informaton1 = [{'ZhangSan' : {"User_Name": "ZhangSan", "Password" : "111111", "balance" : 123165.15, "Account_State" : True , "Error_Count" : 0} }]

# 密码错误次数
Error_Count = 0


# 登录函数
def Account_Verification(sName, sPassword):
    '''
    @Description: 账号认证
    @param : sName：账号  sPassword：密码
    @return: 账号认证是否成功,成功返回账户序号，密码错误返回-1,账户锁定返回-2,账号不存在返回-3
    '''
    # global User_Information
    # for User_Id in range(len(User_Information)):
    #     # 查询用户名是否存在
    #     if sName == User_Information[User_Id]["User_Name"]:
    #         # 检测密码是否正确
    #         if sPassword == User_Information[User_Id]["Password"]:
    #             # 检测账户是否被锁定
    #             if User_Information[User_Id]["Account_State"] == True:
    #                 print("欢迎使用！")
    #                 return User_Id
    #             else:
    #                 print("账号已被锁定！")
    #                 return -2
    #         else:
    #             User_Information[User_Id]["Error_Count"] += 1
    #             print("密码错误,密码错误3次您的账号将被被锁定，您还有{}次机会".format(3 - User_Information[User_Id]["Error_Count"]))
    #             return -1
    #     # else:
    #
    # print("账号不存在！")
    # return -3
    db = DB()
    user_id = db.get_one("select id from userinfo where user = '%s' " % (sName))[0]
    print(user_id)
    if user_id == None:
        print("账号不存在！")
        return -3
    user_count  = db.get_one("select count(*) from userinfo where id = %s and password = '%s'" % (user_id, sPassword))[0]


    if user_count == 0:
        print("密码不对啊")
        info = db.get_one("update userinfo set error_count = error_count + 1 where id = %s" % (user_id))
        print(info)

        # set @ rownum = 0;
        # update
        # a
        # SET
        # id = (
        #         select @ rownum := @ rownum +1 as nid)
        # WHERE
        # id < 10;
        # left_error_count = db.get_one(" select Error_Count from userinfo where id = %s" % (user_id))[0]

        # print('已经错误%s次' % (left_error_count))
        return -1


    is_freeze = db.get_one("select count(*) from userinfo where id = %s and Error_Count >= 3" % (user_id))[0]
    if is_freeze == 1:
        print('账号被冻结')
        return -2
    return user_id

# 余额查询函数
def Account_Balance(User_Id):
    '''
    @Description: 余额查询
    @param : 账户序号
    @return: 无
    '''
    global User_Information
    print("您的余额为{}元！".format(User_Information[User_Id]["balance"]))

# 存款函数
def Deposit_Money(User_Id):

    '''
    @Description: 存款
    @param : 账户序号
    @return: 无
    '''

    global User_Information
    while True:
        #输入存款金额
        money = input("请输入您的存款金额：")
        #存款金额需大于零
        if float(money) <= 0:
            print("请输入大于0的金额！")
        else:
            User_Information[User_Id]["balance"] += int(money)
            print("您已存款{}元，余额为{}元！".format(money,  User_Information[User_Id]["balance"]))
            break

# 取款函数
def withdraw_Money(User_Id):
    '''
    @Description: 取款
    @param : 账户序号
    @return: 无
    '''
    global User_Information
    while True:
        # 输入取款金额
        money = input("请输入您的取款金额：")
        # 取款金额需大于零
        if float(money) <= 0:
            print("请输入大于0的金额！")
        # 取款金额需小于余额
        elif float(money) > User_Information[User_Id]["balance"]:
            print("您的余额不足！")
        else:
            User_Information[User_Id]["balance"] -= float(money)
            print("您已取款{}元，余额为{}元，请核对现金！".format(money,  User_Information[User_Id]["balance"]))
            break

# 修改密码
def Change_Password(User_Id):
    '''
    @Description: 修改密码
    @param : 账户序号
    @return: 无
    '''
    global User_Information
    global Error_Count
    while True:
        # 判断密码错误次数
        if User_Information[User_Id]["Error_Count"] == 3:
            User_Information[User_Id]["Account_State"] = False
            print("账号已被锁定")
            break
        # 输入原密码
        sPassword_Old = input("请输入原密码(输入q取消)：")
        # 退出需改密码程序
        if str(sPassword_Old) == "q":
            break
        if str(sPassword_Old) != User_Information[User_Id]["Password"]:
            User_Information[User_Id]["Error_Count"] += 1
            print("密码错误！数错3次密码将被锁定！您还有{}次机会".format(3 - User_Information[User_Id]["Error_Count"]))
            continue
        # 3次修改密码机会
        for n in range(3):
            sPassword_New1 = input("请输入新密码：")
            sPassword_New2 = input("请再次输入新密码：")
            if sPassword_New1 != sPassword_New2:
                print("密码不一致！")
                print("密码不一致3次，修改密码将失败！目前错误次数{}".format(n + 1))
                continue
            User_Information[User_Id]["Password"] = str(sPassword_New2)
            print("密码修改成功！")
            break
        break

# 登陆界面
while True:
    # 输入初始界面
    print("=" * 20, "自动取款机系统", "=" * 20)
    # 输入用户名密码并检验
    sUser_Name = input("请输入用户名：")
    sPass_Word = getpass.getpass("请输入密码(不可见，放心输入)：")
    User_Id = Account_Verification(sUser_Name, sPass_Word) 
    if User_Id < 0:
        continue
    # 功能选择界面
    while True:
        if User_Information[User_Id]["Account_State"] == False:
            print("账号已被锁定")
            break
        print("=" * 22, "请选择业务", "=" * 22)
        print("{0:1} {1:13} {2:15}".format(" ", "1. 余额查询", "2. 存款"))
        print("{0:1} {1:15} {2:15}".format(" ", "3. 取款", "4. 修改密码"))
        print("{0:1} {1:13}".format(" ", "5. 退出程序"))
        print("=" * 56)
        key = input("请输入任务编号：")
        #功能模块
        if key == "1":
            print("=" * 23, "余额查询", "=" * 23)
            Account_Balance(User_Id)
            input("按回车键继续")
        elif key == "2":
            print("=" * 25, "存款", "=" * 25)
            Deposit_Money(User_Id)
            input("按回车键继续")
        elif key == "3":
            print("=" * 25, "取款", "=" * 25)
            withdraw_Money(User_Id)
            input("按回车键继续")
        elif key == "4":
            print("=" * 23, "修改密码", "=" * 23)
            Change_Password(User_Id)
            input("按回车键继续")
        elif key == "5":
            print("=" * 23, "退出程序", "=" * 23)
            break
        else:
            print("=" * 23, "输入无效", "=" * 23)
            input("按回车键继续")



