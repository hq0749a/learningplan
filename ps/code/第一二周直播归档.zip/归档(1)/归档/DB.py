# -*- coding: utf-8 -*-
# @File  : DB.py
# @Author: yh
# @Date  : 2020/1/9
# @Software: PyCharm


import pymysql


class DB(object):
    def __init__(self):
        # 打开数据库连接
        self.db_connect = pymysql.connect(host="localhost",user="root",password="12345678",db="atmdb",charset="utf8")
        # 使用cursor()方法创建一个游标对象cursor
        self.cursor = self.db_connect.cursor()

    def get_one(self, sql_str):
        try:
            # 使用execute()方法执行SQL查询
            print(sql_str)
            self.cursor.execute(sql_str)
            print("本次查询条数：", self.cursor.rowcount)
            # 使用fetchone()方法获取单条数据.
            while True:
                data = self.cursor.fetchone();
                return data
        except Exception as err:
            print("SQL执行错误，原因：", err)

    def get_data(self, sql_str):
        try:
            # 使用execute()方法执行SQL查询
            self.cursor.execute(sql_str)
            print("本次查询条数：", self.cursor.rowcount)
            # 使用fetchall()获取所有结果
            alist = self.cursor.fetchall()
            return alist
        except Exception as err:
            print("SQL执行错误，原因：", err)

    def add_data(self, tableName, data):
        data_str = ",".join(data)
        # 定义添加sql语句
        sql = "insert into %s values(%s)" % (tableName, data_str)
        try:
            # 使用execute()方法执行SQL
            m = self.cursor.execute(sql)
            # 事务提交
            self.db_connect.commit()
            print("成功操作条数：", m)
            # print("成功操作条数：",cursor.rowcount)
        except Exception as err:
            # 事务回滚
            self.db_connect.rollback()
            print("SQL执行错误，原因：", err)

    def __del__(self):
        # 关闭数据库
        self.db_connect.close()