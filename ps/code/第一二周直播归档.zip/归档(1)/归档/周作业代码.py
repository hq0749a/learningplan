# -*- coding: utf-8 -*-
# @File  : 周作业代码.py
# @Author: yh
# @Date  : 2019/8/14
# @Software: PyCharm

class Student(object):
    count = 0
    def __init__(self, name):
        self.__name = name
        self.__age = -1
        Student.count += 1

    @property
    def age(self):
        return self.__age

    @age.setter
    def age(self, age):
        self.__age = age

    @property
    def birth(self):
        return 2019 - self.__age


a = Student('a')
b = Student('b')
c = Student('c')
d = Student('d')
a.age = 18
print(a.age)
print(a.birth)


print(Student.count)


'''
    设计一个装饰器，查看函数调用时间
'''
def computer_runtime(func):
    def wrapper(*args, **kwargs):
        import time
        start = time.time()
        result = func(*args, **kwargs)
        end = time.time()
        print('%s 执行 %f 秒' % (func.__name__,end - start))
        return result
    return wrapper



@computer_runtime
def computer():
    l = [x ** 2 for x in range(100000)]

computer()

# m = computer_runtime(computer)
# m()

